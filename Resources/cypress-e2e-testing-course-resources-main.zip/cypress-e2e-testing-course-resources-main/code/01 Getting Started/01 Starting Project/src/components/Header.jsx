function Header() {
  return (
    <header>
      <img />
      <h1>Getting Started with Cypress</h1>
    </header>
  );
}

export default Header;
